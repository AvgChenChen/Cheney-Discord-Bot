let Discord = require("discord.js");
let client = new Discord.Client();

client.on("message", message => {
  //Start

  if (message.content === "yo") {
    message.react("🤔");
    message.channel.send('try doing "Cheney Help"');
  }

  //Commands

  //C1
  if (message.content === "yo what is my avatar") {
    message.channel.send("Kinda ba- I mean what, It is GREAT!");
    message.reply(message.author.displayAvatarURL());
  }
  //C2
  if (message.content === "yo who are you") {
    message.channel.send(
      "My name Cheney and I play soccer and hockey. School is wasting my time. But you can subscribe to TheAverageBois in your time!"
    );
    message.reply(
      "Subscribe!" + "https://www.youtube.com/channel/UCIVEkmvMCqOycCso9uwdGmQ"
    );
  }
  //C3
  const things = [
    "Editing the next youtube vid",
    "...Drugs...",
    "Playing Video Games",
    "Streaming on twitch, avg_chenchen",
    "Stupid School",
    "chillin, you?",
    "sad boi hours"
  ];
  const random = Math.floor(Math.random() * things.length);
  if (message.content === "yo what you doing rn") {
    message.reply(things[random]);
  }
  //C4
  if (message.content === "yo do math") {
    let answer1 = Math.floor(Math.random() * 1001);
    let answer2 = Math.floor(Math.random() * 1001);
    let answer3 = answer1 + answer2;
    let answer4 = answer1 - answer2;
    let answer5 = answer1 * answer2;
    let answer6 = answer1 / answer2;
    message.channel.send(answer1 + " + " + answer2 + " = " + answer3);
    message.channel.send(answer1 + " - " + answer2 + " = " + answer4);
    message.channel.send(answer1 + " * " + answer2 + " = " + answer5);
    message.channel.send(answer1 + " ÷ " + answer2 + " = " + answer6);
  }
  //C5
  if (message.content === "yo how are you") {
    message.reply("Good, and you");
    message.channel.send(
      "https://media1.tenor.com/images/62066ca954badad5bb9c3470556244ba/tenor.gif?itemid=12080485"
    );
  }
  //C6
  if (message.content === "yo lets play ping pong") {
    message.reply("Ping, do pong");
  }

  if (message.content === "pong") {
    message.reply("ping");
  }
  //C7
  let jokes = [
    "https://media1.tenor.com/images/1d3dbde35b3725548664adfdfe18dcbb/tenor.gif?itemid=3965503",
    "https://media.tenor.com/images/16469e46dcb4bd58355ad5f7d1e7b555/tenor.gif",
    "https://media1.tenor.com/images/0c7512506d5ae8e934342bc9dbcd24f5/tenor.gif?itemid=18509739",
    "https://media1.tenor.com/images/aff7af8698546d480e4eaa08607f0a46/tenor.gif?itemid=14043748",
    "https://media1.tenor.com/images/0f678d9983140b18eccf33fa8f02cbc9/tenor.gif?itemid=3965525",
    "https://media1.tenor.com/images/86f3b65249fbaca12e142281558c06ac/tenor.gif?itemid=4486363",
    "https://media1.tenor.com/images/d8cf25d023d89205bd6c99184dd180f6/tenor.gif?itemid=16996853"
  ];
  if (message.content === "yo hehe") {
    message.channel.send(jokes[random]);
  }
  //C8
  let i = 0;
  if (message.content === "yo annoy") {
    for (i = 0; i < 20; i++) {
      message.reply("");
    }
    message.channel.send("are you annoyed?");
    if (message.content === "no") {
      for (i = 0; i < 50; i++) {
        message.reply("");
      }
    }
  }
  //C9

  let num = Math.floor(Math.random() * 100000);
  if (message.content === "yo guess my number") {
    message.channel.send(num);
    message.channel.send("right or wrong");
  }
  if (message.content === "right") {
    message.channel.send(
      "https://media1.tenor.com/images/f00815c2e7b2e39cdf28ac0b2e1d516b/tenor.gif?itemid=10617231"
    );
  } else if (message.content === "wrong") {
    message.channel.send(num);
    message.channel.send("right or wrong");
  }
  //C10
  let spodify = [
    "https://open.spotify.com/playlist/5xdlgxNHycAPKiJcx2u7DF",
    "https://open.spotify.com/playlist/5TG4rpokyVLa86PkQMJWGR",
    "https://open.spotify.com/playlist/0eo9RkXvU3OhgDg3XZEdOZ"
  ];
  if (message.content === "yo song picks") {
    message.reply(spodify[random]);
  }
  //C11
  if (message.content === "yo workout") {
    message.reply("alright, 20 push ups" + " 30 sit ups" + " and 20 squats!");
    message.channel.send(
      "https://media1.tenor.com/images/8d47ab78bfc232d646df316cf344fb61/tenor.gif?itemid=14033198"
    );
  }

  //C12
  if (message.content === "yo idea") {
    message.channel.send(
      "I dont have anymore ideas cause the person programming me" +
        " is brain dead, do you have any suggestions?"
    );
  }

  //C13
  let bars1 = [
    "you got her siri but you never gonna use it",
    "when you take a shower you smell be kiinda sour so go and get yourself some baby powder!",
    "clout my a**, you have non of it. Go back to mama's house to get another rehab!"
  ];
  let bars2 = [
    "so where you going on this street",
    "Going to mama's house I see",
    "let me see you hit the woah and peace!"
  ];
  let bars3 = [
    "still scrolling on your phone",
    "on your ass not making bread",
    "stfu and get off yo phone to get that whip you want"
  ];
  let bars4 = [
    "its sad to see you alone",
    "it really is nobody want you needs you, you just there like wtf ",
    "SYKE not even the covid virus want to see you!"
  ];
  const barssAll = [bars1, bars2, bars3, bars4];
  if (message.content === "yo rap") {
    message.reply(barssAll[random]);
  }

  if (message.content === "yo weather") {
    message.channel.send(
      "https://www.google.com/search?q=weather&rlz=1C1CHBD_enCA922CA922&oq=weather+&aqs=chrome.0.35i39i285j35i39j0i131i395i433j0i131i395i433i457j0i395i402l2j0i131i395i433l2.982j1j7&sourceid=chrome&ie=UTF-8"
    );
    message.channel.send(
      "https://tenor.com/view/weather-22jumpstreet-awkward-do-you-like-weather-gif-10188554"
    );
  }

  //C14

  //Help Command
  if (message.content === "Cheney Help") {
    let embed = new Discord.MessageEmbed()
      .setTitle("My Commands:")
      .setDescription('Prefix "yo"')
      .setColor("RANDOM")
      .setFooter(
        "what is my avatar, do math, how are you, lets play ping pong, who are you, what you doing rn, hehe, annoy, guess my number, song picks, workout, idea, rap, weather"
      );
    message.channel.send(embed);
  }
});

client.login("Nzk3NjE3NzE2MjY0NTY2Nzg0.X_pFYg.pGBASd-CwQ-dlrn5EN0uRTMg59A");
